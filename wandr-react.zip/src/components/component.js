import React from 'react'

import './component.css'

const AppComponent = (props) => {
  return <div className="component-container"></div>
}

export default AppComponent
